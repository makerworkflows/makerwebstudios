"""
templates/audit_02_blind_spot.py
─────────────────────────────────────────────────────────────────────────────
Maker Web Studios — Blind Spot Audit Template

HOW TO FILL:
  • Each blind spot has a GAP, WHY_IT_MATTERS, and THE_FIX paragraph.
  • The summary_table rows mirror the blind spots for the scorecard view.
  • Add or remove blind spots from the list — the builder loops over them.
─────────────────────────────────────────────────────────────────────────────
"""

import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from lib.pdf_styles import *

CONTENT = {

    # ── Cover & header ────────────────────────────────────────────────────────
    "client_name":  "CLIENT NAME HERE",                           # ← FILL
    "industry":     "Industry Description",                        # ← FILL
    "date":         "March 2026",                                 # ← FILL

    # ── Executive Summary ─────────────────────────────────────────────────────
    "stat_row1": [
        ("Founding Year", "YEAR"),                                # ← FILL
        ("Employees", "NUMBER"),                                  # ← FILL
        ("Locations", "NUMBER"),                                  # ← FILL
    ],
    "stat_row2": [
        ("Key Size Metric", "VALUE"),                             # ← FILL
        ("Revenue Risk Level", "HIGH"),                           # ← FILL
        ("Avg. Fix Complexity", "MEDIUM"),                        # ← FILL
    ],
    "exec_summary": (
        "One or two sentences summarizing what the Blind Spot Audit found "
        "and the nature of the gaps. Be specific to the client."   # ← FILL
    ),

    # ── Summary Table rows (Blind Spot, Revenue Risk, Fix Complexity, Notes) ─
    "summary_table": [
        ("Brief blind spot name", "HIGH",   "LOW",    "One-line fix description."),  # ← FILL
        ("Brief blind spot name", "HIGH",   "LOW",    "One-line fix description."),
        ("Brief blind spot name", "HIGH",   "MEDIUM", "One-line fix description."),
        ("Brief blind spot name", "MEDIUM", "LOW",    "One-line fix description."),
        ("Brief blind spot name", "MEDIUM", "MEDIUM", "One-line fix description."),
    ],

    # ── Blind Spots ───────────────────────────────────────────────────────────
    # Each entry = (Section Number, Title, Gap, Why It Matters, The Fix)
    # Section numbers start at 3 (S01=Exec, S02=Summary Table, S03+ = spots)
    "blind_spots": [
        (
            3,
            "Blind Spot 1 — [Name the Gap]",                     # ← FILL
            "Describe the gap in detail. What is missing, absent, or broken "
            "in the way the business currently operates? Be specific.",  # ← FILL (GAP)
            "Explain the business consequence. What revenue, relationships, "
            "or opportunities are being lost because of this gap?",       # ← FILL (WHY)
            "Describe the concrete fix. What specifically should be built, "
            "implemented, or changed? How long will it take?",            # ← FILL (FIX)
        ),
        (
            4,
            "Blind Spot 2 — [Name the Gap]",                     # ← FILL
            "Gap description.",
            "Why it matters.",
            "The fix.",
        ),
        (
            5,
            "Blind Spot 3 — [Name the Gap]",                     # ← FILL
            "Gap description.",
            "Why it matters.",
            "The fix.",
        ),
        (
            6,
            "Blind Spot 4 — [Name the Gap]",                     # ← FILL
            "Gap description.",
            "Why it matters.",
            "The fix.",
        ),
        (
            7,
            "Blind Spot 5 — [Name the Gap]",                     # ← FILL
            "Gap description.",
            "Why it matters.",
            "The fix.",
        ),
    ],

    # ── Strategic Recommendations table (Action, Expected Outcome) ─────────
    "recommendations": [
        ("Recommended action one. Be specific about what to do.",
         "Expected business outcome of taking this action."),      # ← FILL
        ("Recommended action two.", "Expected outcome."),
        ("Recommended action three.", "Expected outcome."),
        ("Recommended action four.", "Expected outcome."),
        ("Recommended action five.", "Expected outcome."),
    ],

    "closing_paragraph": (
        "Write a 2–3 sentence closing that ties the blind spots together "
        "and frames them as a coherent growth opportunity rather than "
        "isolated problems. End on an optimistic, actionable note."  # ← FILL
    ),
}

# ══════════════════════════════════════════════════════════════════════════════
# BUILDER
# ══════════════════════════════════════════════════════════════════════════════

def build(client, logo_path, output_dir):
    C = CONTENT
    client_name = client["name"]
    doc_title   = "Blind Spot Audit"
    out_path    = os.path.join(output_dir, f"02_BlindSpot_Audit_{client['slug']}.pdf")

    toc_items = [("01","Executive Summary"), ("02","Blind Spot Priority Table")]
    for num, title, *_ in C["blind_spots"]:
        toc_items.append((f"{num:02d}", title))
    toc_items.append((f"{len(C['blind_spots'])+3:02d}", "Strategic Recommendations"))

    story = []
    story += build_cover("BLIND SPOT AUDIT",
                         "BLIND SPOT", "AUDIT REPORT",
                         f"{client_name} — Strategic Gaps That Are Suppressing Revenue",
                         client["date"])
    story += build_toc(toc_items)

    # S01 Exec Summary
    story.append(PageBreak())
    story += section_label(1, "Executive Summary")
    story.append(Paragraph(
        "A Blind Spot Audit identifies the strategic, operational, and positioning gaps "
        "that compound over time — the things that do not appear in a daily checklist "
        "but quietly suppress growth, limit margin expansion, and leave a market-leading "
        "company exposed to avoidable competitive risk.", sBody))
    story.append(sp(8))
    story.append(stat_box_row(C["stat_row1"]))
    story.append(sp(5))
    story.append(stat_box_row(C["stat_row2"]))
    story.append(sp(8))
    story.append(Paragraph(C["exec_summary"], sBody))

    # S02 Summary Table
    story.append(PageBreak())
    story += section_label(2, "Blind Spot Priority Table")
    story.append(Paragraph("All blind spots ranked by revenue risk and fix complexity.", sBody))
    story.append(sp(8))
    story.append(four_col_table(
        ["BLIND SPOT", "REVENUE RISK", "FIX COMPLEXITY", "NOTES"],
        C["summary_table"],
        col_widths=[CONTENT_W*0.34, CONTENT_W*0.13, CONTENT_W*0.13, CONTENT_W*0.40]
    ))

    # Individual blind spots
    for sec_num, title, gap, why, fix in C["blind_spots"]:
        story.append(PageBreak())
        story += section_label(sec_num, title)
        story.append(Paragraph("THE GAP", sH3))
        story.append(Paragraph(gap, sBody))
        story.append(sp(4))
        story.append(Paragraph("WHY IT MATTERS", sH3))
        story.append(Paragraph(why, sBody))
        story.append(sp(4))
        story.append(Paragraph("THE FIX", sH3))
        story.append(Paragraph(fix, sBody))

    # Strategic Recommendations
    story.append(PageBreak())
    last_sec = len(C["blind_spots"]) + 2
    story += section_label(last_sec, "Strategic Recommendations")
    story.append(Paragraph(C["closing_paragraph"], sBody))
    story.append(sp(8))
    story.append(two_col_table(
        ["RECOMMENDED ACTION", "EXPECTED OUTCOME"],
        C["recommendations"],
    ))
    story += closing(doc_title)

    build_pdf(out_path, story, doc_title, client_name, logo_path)
    return out_path
