"""
templates/audit_03_market_forecast.py
─────────────────────────────────────────────────────────────────────────────
Maker Web Studios — Market Analysis & 5-Year Forecast Template

HOW TO FILL:
  • Market context paragraphs are plain text — write 2–4 sentences each.
  • forecast_table: 5 rows (Year 1–5), 3 scenarios per row.
  • All other sections follow the same (header, rows) pattern.
─────────────────────────────────────────────────────────────────────────────
"""

import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from lib.pdf_styles import *

CONTENT = {

    # ── Cover ─────────────────────────────────────────────────────────────────
    "client_name":  "CLIENT NAME HERE",                           # ← FILL
    "industry":     "Industry & Market Description",               # ← FILL
    "date":         "March 2026",                                 # ← FILL

    # ── Market Context KPIs ───────────────────────────────────────────────────
    "market_kpis_row1": [
        ("Market Size / Year", "$VALUE"),                         # ← FILL
        ("Projected Market / Year", "$VALUE"),                    # ← FILL
        ("Market CAGR", "X.X%"),                                  # ← FILL
    ],
    "market_kpis_row2": [
        ("Regional Market Stat", "VALUE"),                        # ← FILL
        ("Key Demand Driver", "SHORT LABEL"),                     # ← FILL
        ("Client Revenue Upside", "HIGH / MEDIUM / LOW"),         # ← FILL
    ],

    # ── Market Context paragraphs ─────────────────────────────────────────────
    "market_context_paragraphs": [
        "First paragraph: describe the overall market size, growth rate, "
        "and the national/global context the client operates within.",    # ← FILL
        "Second paragraph: describe the regional/local market dynamics "
        "specific to the client's geography and why timing is favorable.", # ← FILL
        "Third paragraph: describe the client's position within this market "
        "and the strategic question they face.",                           # ← FILL
    ],

    # ── Why the Timing Is Favorable table (Trend, Impact) ────────────────────
    "timing_table": [
        ("Trend or tailwind name",
         "Specific impact on the client's business — how does this trend "
         "create a concrete opportunity for them right now?"),    # ← FILL
        ("Trend or tailwind name", "Impact description."),
        ("Trend or tailwind name", "Impact description."),
        ("Trend or tailwind name", "Impact description."),
        ("Trend or tailwind name", "Impact description."),
    ],

    # ── Revenue Model — service/product lines (Type, Notes) ──────────────────
    "revenue_model": [
        ("Revenue stream / service type",
         "Notes on volume, margin profile, and growth potential."),  # ← FILL
        ("Revenue stream / service type", "Notes."),
        ("Revenue stream / service type", "Notes."),
        ("Revenue stream / service type", "Notes."),
        ("Revenue stream / service type", "Notes."),
    ],

    # ── 5-Year Forecast Scenarios ─────────────────────────────────────────────
    # Scenario descriptions (shown below the table)
    "forecast_conservative_desc": (
        "Describe what 'Conservative' means for this client: "
        "no digital investment, no new business development, status quo."  # ← FILL
    ),
    "forecast_base_desc": (
        "Describe the 'Base Case': website modernized, outreach active, "
        "digital presence built. What does this realistically produce?"    # ← FILL
    ),
    "forecast_optimistic_desc": (
        "Describe 'Optimistic': full execution on all recommendations, "
        "cross-sell activated, new market segments captured."              # ← FILL
    ),
    # The table rows (Year label, Conservative, Base Case, Optimistic)
    "forecast_table": [
        ("Year 1 (2026)", "Conservative %", "Base Case %", "Optimistic %"),  # ← FILL
        ("Year 2 (2027)", "Conservative %", "Base Case %", "Optimistic %"),
        ("Year 3 (2028)", "Conservative %", "Base Case %", "Optimistic %"),
        ("Year 4 (2029)", "Conservative %", "Base Case %", "Optimistic %"),
        ("Year 5 (2030)", "Conservative %", "Base Case %", "Optimistic %"),
    ],

    # ── Key Assumptions table (Assumption, Detail) ────────────────────────────
    "assumptions": [
        ("Assumption label", "Specific detail and source or rationale."),  # ← FILL
        ("Assumption label", "Detail."),
        ("Assumption label", "Detail."),
        ("Assumption label", "Detail."),
        ("Assumption label", "Detail."),
    ],

    # ── The Regional / Niche Advantage section ────────────────────────────────
    "advantage_paragraphs": [
        "Paragraph 1: Describe what the best operators in this niche do "
        "differently and what the inflection point looks like.",    # ← FILL
        "Paragraph 2: Describe the client's specific advantage position "
        "and the opportunity they are closest to capturing.",       # ← FILL
    ],
    # Capability table (Capability, Competitive Value)
    "capabilities": [
        ("Key capability or asset",
         "Why this is a competitive advantage that is hard to replicate."),  # ← FILL
        ("Key capability or asset", "Competitive value."),
        ("Key capability or asset", "Competitive value."),
        ("Key capability or asset", "Competitive value."),
        ("Key capability or asset", "Competitive value."),
    ],

    # ── Risks & Mitigations table (Risk, Mitigation) ─────────────────────────
    "risks": [
        ("Risk name or description",
         "Specific mitigation action the client can take."),        # ← FILL
        ("Risk name", "Mitigation."),
        ("Risk name", "Mitigation."),
        ("Risk name", "Mitigation."),
        ("Risk name", "Mitigation."),
    ],
}

# ══════════════════════════════════════════════════════════════════════════════
# BUILDER
# ══════════════════════════════════════════════════════════════════════════════

def build(client, logo_path, output_dir):
    C = CONTENT
    client_name = client["name"]
    doc_title   = "Market Analysis & 5-Year Forecast"
    out_path    = os.path.join(output_dir,
                               f"03_Market_Forecast_{client['slug']}.pdf")

    story = []
    story += build_cover("MARKET ANALYSIS & 5-YEAR FORECAST",
                         "MARKET ANALYSIS", "& 5-YEAR FORECAST",
                         f"{client_name} — {C['industry']}",
                         client["date"])
    story += build_toc([
        ("01","Market Context"), ("02","Why the Timing Is Favorable"),
        ("03","Revenue Model Overview"), ("04","5-Year Revenue Potential Scenarios"),
        ("05","Key Assumptions"), ("06","The Competitive Advantage"),
        ("07","Risks and Mitigations"),
    ])

    # S01 Market Context
    story.append(PageBreak())
    story += section_label(1, "Market Context")
    for para in C["market_context_paragraphs"]:
        story.append(Paragraph(para, sBody))
        story.append(sp(4))
    story.append(sp(4))
    story.append(stat_box_row(C["market_kpis_row1"]))
    story.append(sp(5))
    story.append(stat_box_row(C["market_kpis_row2"]))

    # S02 Timing
    story.append(PageBreak())
    story += section_label(2, "Why the Timing Is Favorable")
    story.append(Paragraph(
        f"Several converging trends make this an exceptionally favorable moment "
        f"for {client_name} to invest in business development and digital infrastructure.",
        sBody))
    story.append(sp(8))
    story.append(two_col_table(
        ["TREND OR TAILWIND", "IMPACT ON CLIENT"],
        C["timing_table"],
        col_widths=[CONTENT_W*0.35, CONTENT_W*0.65]
    ))

    # S03 Revenue Model
    story.append(PageBreak())
    story += section_label(3, "Revenue Model Overview")
    story.append(Paragraph(
        "The client operates across multiple revenue streams at different margin "
        "profiles. Understanding the relative value of each stream guides where "
        "to prioritize business development investment.", sBody))
    story.append(sp(8))
    story.append(two_col_table(["REVENUE TYPE / SERVICE", "NOTES"], C["revenue_model"]))

    # S04 Forecast
    story.append(PageBreak())
    story += section_label(4, "5-Year Revenue Potential Scenarios")
    story.append(Paragraph("Three scenarios based on investment level and execution against the recommendations in this report.", sBody))
    story.append(sp(4))
    story.append(Paragraph(
        f"Conservative: {C['forecast_conservative_desc']}  "
        f"Base Case: {C['forecast_base_desc']}  "
        f"Optimistic: {C['forecast_optimistic_desc']}", sSmall))
    story.append(sp(8))
    story.append(four_col_table(
        ["YEAR", "CONSERVATIVE", "BASE CASE", "OPTIMISTIC"],
        C["forecast_table"],
    ))

    # S05 Assumptions
    story.append(PageBreak())
    story += section_label(5, "Key Assumptions")
    story.append(sp(6))
    story.append(two_col_table(["ASSUMPTION", "DETAIL"], C["assumptions"]))

    # S06 Advantage
    story.append(PageBreak())
    story += section_label(6, "The Competitive Advantage")
    for para in C["advantage_paragraphs"]:
        story.append(Paragraph(para, sBody))
        story.append(sp(4))
    story.append(sp(4))
    story.append(two_col_table(["KEY CAPABILITY / ASSET", "COMPETITIVE VALUE"], C["capabilities"]))

    # S07 Risks
    story.append(PageBreak())
    story += section_label(7, "Risks and Mitigations")
    story.append(sp(6))
    story.append(two_col_table(["RISK", "MITIGATION"], C["risks"]))
    story += closing(doc_title)

    build_pdf(out_path, story, doc_title, client_name, logo_path)
    return out_path
