"""
templates/audit_04_growth_strategy.py
─────────────────────────────────────────────────────────────────────────────
Maker Web Studios — Growth Strategy Playbook Template
─────────────────────────────────────────────────────────────────────────────
"""

import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from lib.pdf_styles import *

CONTENT = {

    # ── Cover ─────────────────────────────────────────────────────────────────
    "client_name": "CLIENT NAME HERE",                            # ← FILL
    "industry":    "Industry Description",                         # ← FILL
    "date":        "March 2026",                                  # ← FILL

    # ── S01 Honest Assessment ─────────────────────────────────────────────────
    "assessment_paragraphs": [
        "Paragraph 1: Acknowledge the real strength of what they have built. "
        "Be specific — name assets, history, capabilities.",       # ← FILL
        "Paragraph 2: Name the real challenge without being harsh. "
        "What is the gap between their operations and their growth system?", # ← FILL
    ],
    "assessment_kpis": [
        ("Current Growth Model",  "REFERRAL-DRIVEN"),             # ← FILL
        ("Target Growth Model",   "PIPELINE-DRIVEN"),             # ← FILL
        ("Timeline to Transform", "90 DAYS"),                     # ← FILL
    ],

    # ── S02 Services Ranked by Revenue Potential ──────────────────────────────
    # (Service Name, Revenue Rank, Why It Ranks There)
    "service_rankings": [
        ("Service or product line name", "HIGHEST",
         "Why this ranks highest — margin, volume, relationship depth, etc."),  # ← FILL
        ("Service or product line name", "HIGHEST", "Why."),
        ("Service or product line name", "HIGH",    "Why."),
        ("Service or product line name", "HIGH",    "Why."),
        ("Service or product line name", "HIGH",    "Why."),
        ("Service or product line name", "MEDIUM",  "Why."),
    ],

    # ── S03 Target Buyer Profile ──────────────────────────────────────────────
    # (Buyer Type, What They Buy, Why They Are High-Value)
    "buyer_profiles": [
        ("Buyer type name or role",
         "What this buyer purchases from the client.",
         "Why this buyer is high-value — LTV, repeat rate, referral potential."),  # ← FILL
        ("Buyer type name", "What they buy.", "Why high-value."),
        ("Buyer type name", "What they buy.", "Why high-value."),
        ("Buyer type name", "What they buy.", "Why high-value."),
    ],

    # ── S04 Channel Strategy — phases ────────────────────────────────────────
    # List of (Phase Title, Body Paragraph)
    "channel_phases": [
        (
            "Phase 1 — [Name It] (Months 1–2)",                   # ← FILL
            "Describe what happens in this phase: what is built, "
            "launched, or activated and what it unlocks for the client.",  # ← FILL
        ),
        (
            "Phase 2 — [Name It] (Months 2–4)",                   # ← FILL
            "Phase description.",
        ),
        (
            "Phase 3 — [Name It] (Month 3+)",                     # ← FILL
            "Phase description.",
        ),
        (
            "Phase 4 — [Name It] (Month 4+)",                     # ← FILL
            "Phase description.",
        ),
        (
            "Phase 5 — [Name It] (Month 5+)",                     # ← FILL
            "Phase description.",
        ),
    ],

    # ── S05 Positioning ───────────────────────────────────────────────────────
    "positioning_weak":   "Write the weak, commodity version of how this "
                          "company currently describes itself.",   # ← FILL
    "positioning_strong": "Write the strong, outcome-driven version that "
                          "calls out history, capability, logistics, "
                          "service depth, and geography.",         # ← FILL
    "positioning_note":   "One paragraph explaining why the stronger positioning "
                          "wins and how the client should use it across every "
                          "touchpoint: calls, quotes, website headlines, email.",  # ← FILL

    # ── S06 90-Day Growth Activation Plan table ───────────────────────────────
    # (Timeline, Action, Expected Outcome, Responsible Party)
    "activation_plan": [
        ("Week 1–2",
         "Action: what specifically happens.",
         "Expected outcome of this action.",
         "Who owns it"),                                           # ← FILL
        ("Week 2–4", "Action.", "Outcome.", "Owner"),
        ("Month 2",  "Action.", "Outcome.", "Owner"),
        ("Month 2–3","Action.", "Outcome.", "Owner"),
        ("Month 3–4","Action.", "Outcome.", "Owner"),
        ("Month 4–6","Action.", "Outcome.", "Owner"),
    ],
}

# ══════════════════════════════════════════════════════════════════════════════
# BUILDER
# ══════════════════════════════════════════════════════════════════════════════

def build(client, logo_path, output_dir):
    C = CONTENT
    client_name = client["name"]
    doc_title   = "Growth Strategy Playbook"
    out_path    = os.path.join(output_dir,
                               f"04_Growth_Strategy_{client['slug']}.pdf")

    story = []
    story += build_cover("GROWTH STRATEGY PLAYBOOK",
                         "GROWTH STRATEGY", "PLAYBOOK",
                         f"{client_name} — Positioning, Channels & Pipeline That Scales",
                         client["date"])
    story += build_toc([
        ("01","Honest Assessment — Where You Stand Today"),
        ("02","Services Ranked by Revenue Potential"),
        ("03","The Target Buyer Profile"),
        ("04","Channel Strategy — Building a Pipeline Beyond Referrals"),
        ("05","Positioning — How to Talk About What You Do"),
        ("06","The 90-Day Growth Activation Plan"),
    ])

    # S01
    story.append(PageBreak())
    story += section_label(1, "Honest Assessment — Where You Stand Today")
    for para in C["assessment_paragraphs"]:
        story.append(Paragraph(para, sBody))
        story.append(sp(4))
    story.append(sp(4))
    story.append(stat_box_row(C["assessment_kpis"]))

    # S02
    story.append(PageBreak())
    story += section_label(2, "Services Ranked by Revenue Potential")
    story.append(Paragraph(
        "Not all revenue streams are equal. This ranking guides where to "
        "invest business development effort first.", sBody))
    story.append(sp(8))
    story.append(three_col_table(
        ["SERVICE / PRODUCT LINE", "REVENUE RANK", "WHY"],
        C["service_rankings"],
        col_widths=[CONTENT_W*0.38, CONTENT_W*0.14, CONTENT_W*0.48]
    ))

    # S03
    story.append(PageBreak())
    story += section_label(3, "The Target Buyer Profile")
    story.append(Paragraph(
        "Not all buyers are equal. The highest-value accounts share "
        "identifiable characteristics.", sBody))
    story.append(sp(8))
    story.append(three_col_table(
        ["BUYER TYPE", "WHAT THEY BUY", "WHY THEY ARE HIGH-VALUE"],
        C["buyer_profiles"],
    ))

    # S04
    story.append(PageBreak())
    story += section_label(4, "Channel Strategy — Building a Pipeline Beyond Referrals")
    story.append(sp(4))
    for title, body_text in C["channel_phases"]:
        story.append(Paragraph(title, sH3))
        story.append(Paragraph(body_text, sBody))
        story.append(sp(6))

    # S05
    story.append(PageBreak())
    story += section_label(5, "Positioning — How to Talk About What You Do")
    story.append(Paragraph(
        "Most operators in this industry describe themselves the same way. "
        "The strongest positioning speaks to outcomes, history, and capability "
        "in a single statement a competitor cannot match.", sBody))
    story.append(sp(8))
    story.append(two_col_table(
        ["POSITIONING TYPE", "EXAMPLE"],
        [
            ("Weak — commodity",  C["positioning_weak"]),
            ("Strong — outcome",  C["positioning_strong"]),
        ],
    ))
    story.append(sp(8))
    story.append(Paragraph(C["positioning_note"], sBody))

    # S06
    story.append(PageBreak())
    story += section_label(6, "The 90-Day Growth Activation Plan")
    story.append(sp(6))
    story.append(four_col_table(
        ["TIMELINE", "ACTION", "EXPECTED OUTCOME", "RESPONSIBLE"],
        C["activation_plan"],
        col_widths=[CONTENT_W*0.12, CONTENT_W*0.32, CONTENT_W*0.36, CONTENT_W*0.20]
    ))
    story += closing(doc_title)

    build_pdf(out_path, story, doc_title, client_name, logo_path)
    return out_path
