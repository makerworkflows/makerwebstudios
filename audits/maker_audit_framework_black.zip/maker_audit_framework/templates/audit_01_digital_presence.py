"""
templates/audit_01_digital_presence.py
─────────────────────────────────────────────────────────────────────────────
Maker Web Studios — Digital Presence Audit Template
─────────────────────────────────────────────────────────────────────────────

HOW TO USE (for Claude Code or manual fill):
  1. Fill every value in the CONTENT dict below.
  2. This file is imported by run_all_audits.py — do not run it directly.
  3. All design/layout is handled by lib/pdf_styles.py — do not edit that.

FILLING INSTRUCTIONS (marked with ← FILL):
  • Strings: just replace the placeholder text inside the quotes.
  • Lists of tuples: each tuple = one row. Add or remove rows freely.
  • audit_items: each tuple = (STATUS, TITLE, DETAIL)
      STATUS must be exactly "PASS", "WARN", or "FAIL"
  • scorecard_rows: each tuple = (CATEGORY, SCORE_STRING, NOTES)
  • priority_rows: each tuple = (BADGE, NUMBER, TITLE, DETAIL)
      BADGE must be exactly "CRITICAL", "HIGH", or "MEDIUM"
  • doing_right: list of (TITLE, DETAIL) — numbered automatically
─────────────────────────────────────────────────────────────────────────────
"""

import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from lib.pdf_styles import *

# ══════════════════════════════════════════════════════════════════════════════
# CLIENT CONTENT — fill everything below this line
# ══════════════════════════════════════════════════════════════════════════════

CONTENT = {

    # ── Cover & header ────────────────────────────────────────────────────────
    "client_name":   "CLIENT NAME HERE",                          # ← FILL
    "client_url":    "clientwebsite.com",                         # ← FILL
    "industry":      "Industry & Specialty Description Here",      # ← FILL
    "location":      "City, State",                               # ← FILL
    "date":          "March 2026",                                # ← FILL (month year)

    # ── Executive Summary — stat boxes (label, value) ─────────────────────────
    # Row 1: 3 KPIs
    "stat_row1": [
        ("Founding Year / Years in Operation", "YEAR"),           # ← FILL
        ("Key Size Metric (sq ft / employees)", "VALUE"),         # ← FILL
        ("Locations / Branches", "NUMBER"),                       # ← FILL
    ],
    # Row 2: 3 KPIs
    "stat_row2": [
        ("Second Key Metric Label", "VALUE"),                     # ← FILL
        ("Overall Audit Score", "X.X/10"),                        # ← FILL
        ("Revenue Upside Potential", "★★★★★"),                  # ← FILL
    ],

    # ── Executive Summary — two-panel box ─────────────────────────────────────
    "exec_left": [
        ("THE COMPANY",
         "Describe what the company does, who they serve, how long in business, "
         "and their key operational facts."),                      # ← FILL
        ("THE PLATFORM",
         "Describe the website CMS, last update date, tech stack, "
         "and any tracking/analytics issues discovered."),         # ← FILL
    ],
    "exec_right": [
        ("THE CREDENTIALS",
         "List the company's most important trust signals: certifications, "
         "named clients, fleet, team size, exclusivities, etc."),  # ← FILL
        ("THE MARKET REALITY",
         "Describe the competitive environment and the gap between "
         "the company's operational strength and its digital presence."), # ← FILL
    ],

    # ── Executive Summary — pull quote ────────────────────────────────────────
    "exec_quote": (
        "Write the defining strategic opportunity finding as a one-sentence "
        "audit quote. Make it punchy and client-specific.",         # ← FILL
        "Maker Web Studios Audit Finding",
    ),

    # ── Scorecard rows (Category, Score, Notes) ───────────────────────────────
    # Score the company 1–10 on each of the 7 categories.
    # Overall is calculated automatically from these 7.
    "scorecard_rows": [
        ("Design & UX",         "X.X/10", "Notes on design quality, template age, mobile, UX."),       # ← FILL
        ("On-Page SEO",         "X.X/10", "Notes on title tags, meta, H1s, keyword strategy."),        # ← FILL
        ("Technical SEO",       "X.X/10", "Notes on sitemap, schema, analytics, HTTPS, speed."),       # ← FILL
        ("Content Quality",     "X.X/10", "Notes on page depth, FAQs, differentiators, case studies."),# ← FILL
        ("Conversion",          "X.X/10", "Notes on CTAs, RFQ form, lead capture, phone placement."),  # ← FILL
        ("Trust & Credibility", "X.X/10", "Notes on testimonials, reviews, certifications, team page."),# ← FILL
        ("Digital Presence",    "X.X/10", "Notes on social, GBP, LinkedIn, directories, backlinks."),  # ← FILL
    ],

    # ── Market & Competitive Context ─────────────────────────────────────────
    "market_stat_row": [
        ("Market Size / Metric 1", "VALUE"),                      # ← FILL
        ("Market CAGR or Growth Stat", "VALUE"),                  # ← FILL
        ("Regional Growth Stat", "VALUE"),                        # ← FILL
    ],
    # Competitor table: (Name, Profile, Digital Position vs Client)
    "competitors": [
        ("Competitor Name A", "Brief description of who they are.", "How their digital presence compares to the client — where client is at a disadvantage."),  # ← FILL
        ("Competitor Name B", "Brief description of who they are.", "Digital comparison."),   # ← FILL
        ("Competitor Name C", "Brief description of who they are.", "Digital comparison."),   # ← FILL
        ("CLIENT NAME",       "Client's actual strengths.",         "Operational superiority, digital gap. What the gap is and that it's addressable."), # ← FILL
    ],
    "market_quote": (
        "Write a one-sentence finding about the client's visibility gap "
        "relative to competitors in search.",                      # ← FILL
        "Maker Web Studios Audit Finding",
    ),

    # ── Audit sections — each is a list of (STATUS, TITLE, DETAIL) tuples ────
    # STATUS must be exactly "PASS", "WARN", or "FAIL"

    "design_ux_items": [
        # Add as many as needed — typical range 8–12 items
        ("PASS", "Item Title", "Detail explaining what was found and why it matters."),  # ← FILL
        ("WARN", "Item Title", "Detail."),
        ("FAIL", "Item Title", "Detail."),
    ],

    "onpage_seo_items": [
        ("PASS", "Item Title", "Detail."),                        # ← FILL
        ("WARN", "Item Title", "Detail."),
        ("FAIL", "Item Title", "Detail."),
    ],

    "technical_seo_items": [
        ("PASS", "Item Title", "Detail."),                        # ← FILL
        ("WARN", "Item Title", "Detail."),
        ("FAIL", "Item Title", "Detail."),
    ],

    "content_quality_items": [
        ("PASS", "Item Title", "Detail."),                        # ← FILL
        ("WARN", "Item Title", "Detail."),
        ("FAIL", "Item Title", "Detail."),
    ],

    "conversion_items": [
        ("PASS", "Item Title", "Detail."),                        # ← FILL
        ("WARN", "Item Title", "Detail."),
        ("FAIL", "Item Title", "Detail."),
    ],

    "trust_items": [
        ("PASS", "Item Title", "Detail."),                        # ← FILL
        ("WARN", "Item Title", "Detail."),
        ("FAIL", "Item Title", "Detail."),
    ],

    "digital_presence_items": [
        ("PASS", "Item Title", "Detail."),                        # ← FILL
        ("WARN", "Item Title", "Detail."),
        ("FAIL", "Item Title", "Detail."),
    ],

    # ── What They Are Doing Right — list of (TITLE, DETAIL) ──────────────────
    # Numbered automatically 1, 2, 3...
    "doing_right": [
        ("Strength Title", "Description of the genuine competitive advantage and why it matters."),  # ← FILL
        ("Strength Title", "Description."),
        ("Strength Title", "Description."),
        # Add or remove items freely — aim for 8–12
    ],

    # ── Priority Fix Table ────────────────────────────────────────────────────
    # BADGE must be exactly "CRITICAL", "HIGH", or "MEDIUM"
    # NUMBER is just a sequential display number
    "priority_critical": [
        ("CRITICAL", 1, "Fix Title", "Specific action to take and why it matters most."),  # ← FILL
        ("CRITICAL", 2, "Fix Title", "Action."),
        ("CRITICAL", 3, "Fix Title", "Action."),
    ],
    "priority_high": [
        ("HIGH", 4, "Fix Title", "Action within 30 days."),       # ← FILL
        ("HIGH", 5, "Fix Title", "Action."),
    ],
    "priority_medium": [
        ("MEDIUM", 6, "Fix Title", "Action within 60 days."),     # ← FILL
        ("MEDIUM", 7, "Fix Title", "Action."),
    ],

    # ── 90-Day Roadmap — three phases, each with a list of bullet strings ─────
    "roadmap": [
        (
            "PHASE 1 — Days 1–30: Foundation",
            [
                "Action item one.",                               # ← FILL
                "Action item two.",
                "Action item three.",
            ]
        ),
        (
            "PHASE 2 — Days 31–60: Content & Trust",
            [
                "Action item one.",                               # ← FILL
                "Action item two.",
            ]
        ),
        (
            "PHASE 3 — Days 61–90: Lead Generation & SEO Flywheel",
            [
                "Action item one.",                               # ← FILL
                "Action item two.",
            ]
        ),
    ],

    # ── Strategic Opportunity — closing narrative (3–5 paragraphs) ───────────
    "strategic_paragraphs": [
        "First paragraph: acknowledge what the company has built operationally. "
        "Be specific — name the assets, the history, the team.",    # ← FILL
        "Second paragraph: describe the digital gap and what it costs them.",
        "Third paragraph: describe the market opportunity right now.",
        "Fourth paragraph: describe the transformation available with investment.",
    ],
    "strategic_quote": (
        "Closing audit quote — one sentence on what the right next move is.",  # ← FILL
        "Maker Web Studios Audit Finding",
    ),
}

# ══════════════════════════════════════════════════════════════════════════════
# BUILDER — do not edit below this line
# ══════════════════════════════════════════════════════════════════════════════

def build(client, logo_path, output_dir):
    """Called by run_all_audits.py. Returns the output file path."""

    C = CONTENT  # shorthand

    # Auto-calculate overall score from the 7 scorecard rows
    def _score(s):
        try:
            return float(s.split("/")[0])
        except Exception:
            return 0.0
    scores = [_score(r[1]) for r in C["scorecard_rows"]]
    overall = sum(scores) / len(scores) if scores else 0.0

    client_name = client["name"]
    doc_title   = "Digital Presence Audit"
    subtitle    = f"{client_name} — {client['industry']}"
    out_path    = os.path.join(output_dir, f"01_Digital_Presence_Audit_{client['slug']}.pdf")

    story = []

    # Cover
    story += build_cover("DIGITAL PRESENCE AUDIT",
                         "DIGITAL PRESENCE", "AUDIT REPORT",
                         subtitle, client["date"])

    # TOC
    story += build_toc([
        ("01","Executive Summary"), ("02","Audit Scorecard"),
        ("03","Market & Competitive Context"), ("04","Design & UX Audit"),
        ("05","On-Page SEO Audit"), ("06","Technical SEO Audit"),
        ("07","Content Quality Audit"), ("08","Conversion Audit"),
        ("09","Trust & Credibility Audit"), ("10","Digital Presence Audit"),
        ("11","What They Are Doing Right"), ("12","Priority Fix Table"),
        ("13","90-Day Fix Roadmap"), ("14","Strategic Opportunity"),
    ])

    # S01 Executive Summary
    story.append(PageBreak())
    story += section_label(1, "Executive Summary")
    story.append(Paragraph(
        f"A comprehensive analysis of {C['client_url']}'s digital presence, "
        f"market positioning, and growth opportunities.", sBody))
    story.append(sp(8))
    story.append(stat_box_row(C["stat_row1"]))
    story.append(sp(5))
    story.append(stat_box_row(C["stat_row2"]))
    story.append(sp(8))

    def _panel(blocks):
        out = []
        for label, text in blocks:
            out += [Paragraph(label, sBodyBold), Paragraph(text, sSmall), sp(4)]
        return out

    story.append(two_panel_box(_panel(C["exec_left"]), _panel(C["exec_right"])))
    story.append(sp(10))
    story += quote(*C["exec_quote"])

    # S02 Scorecard
    story.append(PageBreak())
    story += section_label(2, "Audit Scorecard")
    story.append(Paragraph("Overall performance across seven critical website and digital presence categories.", sBody))
    story.append(sp(8))
    story.append(scorecard_table(C["scorecard_rows"]))
    story.append(sp(8))
    story.append(Paragraph(
        f"OVERALL SCORE: {overall:.1f} / 10  —  "
        "Review each section below for specific findings and recommended actions.",
        sBodyBold))

    # S03 Market & Competitive Context
    story.append(PageBreak())
    story += section_label(3, "Market & Competitive Context")
    story.append(Paragraph(
        f"Understanding the {C['industry']} landscape and competitive dynamics "
        f"{client_name} operates within.", sBody))
    story.append(sp(8))
    story.append(stat_box_row(C["market_stat_row"]))
    story.append(sp(8))
    story.append(three_col_table(
        ["COMPETITOR", "PROFILE", "DIGITAL POSITION VS. CLIENT"],
        C["competitors"],
        col_widths=[CONTENT_W*0.22, CONTENT_W*0.28, CONTENT_W*0.50]
    ))
    story.append(sp(10))
    story += quote(*C["market_quote"])

    # Audit sections S04–S10
    audit_sections = [
        (4,  "Design & UX Audit",
         "Visual design, user experience, and interface assessment.",
         "design_ux_items"),
        (5,  "On-Page SEO Audit",
         "Search engine optimization at the page level: titles, meta descriptions, keywords, and content structure.",
         "onpage_seo_items"),
        (6,  "Technical SEO Audit",
         "Under-the-hood technical factors that determine crawlability, indexing, and search performance.",
         "technical_seo_items"),
        (7,  "Content Quality Audit",
         "Evaluating the depth, uniqueness, and strategic value of website content across all pages.",
         "content_quality_items"),
        (8,  "Conversion Audit",
         "How effectively the website converts visitors into leads, inquiries, and sales conversations.",
         "conversion_items"),
        (9,  "Trust & Credibility Audit",
         "How the website builds buyer confidence through social proof, reviews, and institutional transparency.",
         "trust_items"),
        (10, "Digital Presence Audit",
         "Social media footprint, directory listings, and off-site visibility across the digital ecosystem.",
         "digital_presence_items"),
    ]
    for num, title, intro, key in audit_sections:
        story.append(PageBreak())
        story += section_label(num, title)
        story.append(Paragraph(intro, sBody))
        story.append(sp(6))
        for item in C[key]:
            story += audit_item(*item)

    # S11 Doing Right
    story.append(PageBreak())
    story += section_label(11, "What They Are Doing Right")
    story.append(Paragraph("Credit where it is due. Legitimate competitive advantages that form the foundation for growth.", sBody))
    story.append(sp(6))
    for i, (t, d) in enumerate(C["doing_right"], 1):
        story += doing_right_item(i, t, d)

    # S12 Priority Fix Table
    story.append(PageBreak())
    story += section_label(12, "Priority Fix Table")
    story.append(Paragraph("Ranked improvements by impact and urgency. Address Critical items first.", sBody))
    story.append(sp(6))
    story.append(Paragraph("CRITICAL — Immediate Action Required", sBodyBold))
    story.append(sp(4))
    story.append(priority_table(C["priority_critical"]))
    story.append(sp(8))
    story.append(Paragraph("HIGH — Address Within 30 Days", sBodyBold))
    story.append(sp(4))
    story.append(priority_table(C["priority_high"]))
    story.append(sp(8))
    story.append(Paragraph("MEDIUM — Address Within 60 Days", sBodyBold))
    story.append(sp(4))
    story.append(priority_table(C["priority_medium"]))

    # S13 Roadmap
    story.append(PageBreak())
    story += section_label(13, "90-Day Fix Roadmap")
    story.append(Paragraph(
        f"A phased execution plan to transform {C['client_url']} into the "
        "company's strongest lead generation and trust-building asset.", sBody))
    story.append(sp(8))
    for phase_title, items in C["roadmap"]:
        story += phase_block(phase_title, items)

    # S14 Strategic Opportunity
    story.append(PageBreak())
    story += section_label(14, "Strategic Opportunity")
    for para in C["strategic_paragraphs"]:
        story.append(Paragraph(para, sBody))
        story.append(sp(4))
    story.append(sp(6))
    story += quote(*C["strategic_quote"])
    story += closing(doc_title)

    build_pdf(out_path, story, doc_title, client_name, logo_path)
    return out_path
