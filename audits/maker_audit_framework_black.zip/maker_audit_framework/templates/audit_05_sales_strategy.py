"""
templates/audit_05_sales_strategy.py
─────────────────────────────────────────────────────────────────────────────
Maker Web Studios — Sales Strategy & Irresistible Offer Playbook Template
─────────────────────────────────────────────────────────────────────────────
"""

import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from lib.pdf_styles import *

CONTENT = {

    # ── Cover ─────────────────────────────────────────────────────────────────
    "client_name": "CLIENT NAME HERE",                            # ← FILL
    "industry":    "Industry Description",                         # ← FILL
    "date":        "March 2026",                                  # ← FILL

    # ── S01 The Commodity Problem ─────────────────────────────────────────────
    "commodity_paragraphs": [
        "Paragraph 1: Describe how most operators in this industry present "
        "themselves and why that framing turns every evaluation into a "
        "price comparison.",                                       # ← FILL
        "Paragraph 2: Name the client's actual capabilities and describe "
        "the gap between what they deliver and what the market perceives "
        "when they use generic positioning.",                      # ← FILL
    ],

    # ── S02 What the Client Actually Sells ───────────────────────────────────
    # (What You Deliver, The Real Outcome for the Buyer)
    "actual_sells": [
        ("What the client delivers (product/service)",
         "The real outcome this creates for the buyer — the feeling, "
         "the relief, the result they actually care about."),      # ← FILL
        ("Deliverable", "Outcome."),
        ("Deliverable", "Outcome."),
        ("Deliverable", "Outcome."),
        ("Deliverable", "Outcome."),
        ("Deliverable", "Outcome."),
    ],

    # ── S03 The Value Equation ────────────────────────────────────────────────
    # (Value Driver, Goal, Client Application)
    "value_equation": [
        ("Dream Outcome",                   "Increase",
         "What does the buyer's ideal outcome look like for this client's services?"),  # ← FILL
        ("Perceived Likelihood of Achievement", "Increase",
         "What proof points, history, or credentials increase buyer confidence?"),
        ("Time Delay",                      "Decrease",
         "How does the client reduce the time between order and result?"),
        ("Effort and Sacrifice",            "Decrease",
         "How does the client reduce the work or risk the buyer has to take on?"),
    ],
    "value_note": (
        "One paragraph explaining why reducing the denominator (time delay + "
        "effort) is the more powerful lever than just making bigger promises, "
        "and how the client's capabilities do exactly that."       # ← FILL
    ),

    # ── S04 Define the Niche ──────────────────────────────────────────────────
    "avatar_description": (
        "Describe the ideal client avatar in specific terms: their role, "
        "their geography, their pain, their budget authority, and why they "
        "are most likely to buy based on value rather than price."  # ← FILL
    ),
    # (Avatar Characteristic, Why It Matters for Sales)
    "avatar_table": [
        ("Avatar characteristic",
         "Why this specific characteristic makes them the ideal buyer and "
         "how it affects the sales conversation."),                # ← FILL
        ("Characteristic", "Sales implication."),
        ("Characteristic", "Sales implication."),
        ("Characteristic", "Sales implication."),
    ],

    # ── S05 The Four Market Indicators ───────────────────────────────────────
    # (Indicator, Client Reality Check)
    "market_indicators": [
        ("Massive Pain",
         "Describe the specific, recurring pain this buyer experiences "
         "that the client directly eliminates. Be concrete."),     # ← FILL
        ("Purchasing Power",
         "Describe why this buyer has budget authority and why price "
         "sensitivity is lower than the client may assume."),
        ("Easy to Target",
         "Describe the channels, directories, or networks where this "
         "buyer is identifiable and reachable."),
        ("Growing Market",
         "Cite the market growth stats and trends that confirm this "
         "is an expanding opportunity, not a shrinking one."),
    ],

    # ── S06 Name the Offer ────────────────────────────────────────────────────
    # (Offer Type, Named Version)
    "named_offers": [
        ("Generic (old)",   "Write the generic, commodity version of how they currently "
                            "describe this service."),             # ← FILL
        ("Named Offer 1 (new)",
         "Write the new named version using: magnetic reason + specific buyer + "
         "goal/outcome + timeframe + container word. "
         "Example: 'The [Name] Program — [what it does] for [who] so that [outcome].'"),  # ← FILL
        ("Named Offer 2 (new, different segment)",
         "Second named offer for a different buyer type or service tier."),
    ],
    "naming_note": (
        "One paragraph on why named offers are more referable, more memorable, "
        "and convert better than generic service descriptions — and how the "
        "client should deploy these names across calls, quotes, and the website."  # ← FILL
    ),

    # ── S07 The Offer Stack ───────────────────────────────────────────────────
    # (Offer Component, Obstacle It Addresses, Perceived Value)
    "offer_stack": [
        ("Core product or service",
         "The primary desire — solved.",
         "High — the anchor offer."),                             # ← FILL
        ("Component 2", "Obstacle it removes.", "Perceived value."),
        ("Component 3", "Obstacle it removes.", "Perceived value."),
        ("Component 4", "Obstacle it removes.", "Perceived value."),
        ("Component 5", "Obstacle it removes.", "Perceived value."),
        ("Component 6", "Obstacle it removes.", "Perceived value."),
    ],

    # ── S08 Pricing & Framing ─────────────────────────────────────────────────
    "pricing_weak":   "Write the weak, price-first framing currently used.",  # ← FILL
    "pricing_strong": "Write the strong, value-first framing that communicates "
                      "capability, process, and risk elimination before the "
                      "price is ever stated.",                     # ← FILL
    "pricing_note":   "One paragraph on why the strong framing wins the "
                      "value conversation before price is even mentioned, "
                      "and the only scenario where price-first framing helps.",  # ← FILL

    # ── S09 Guarantees ────────────────────────────────────────────────────────
    # List of (Guarantee Name, Guarantee Description)
    "guarantees": [
        ("Layer 1 — [Name the Guarantee]",
         "Write the specific guarantee language. What does the client "
         "promise and what happens if they fail to deliver? "
         "Keep it something they can actually stand behind."),     # ← FILL
        ("Layer 2 — [Name the Guarantee]", "Guarantee description."),
        ("Layer 3 — [Name the Guarantee]", "Guarantee description."),
    ],

    # ── S10 Real Urgency ──────────────────────────────────────────────────────
    # (Urgency Driver, How to Use It)
    "urgency_drivers": [
        ("Urgency driver name (must be real, not manufactured)",
         "Specific language or mechanism for communicating this urgency "
         "authentically in sales conversations and on the website."),  # ← FILL
        ("Urgency driver", "How to use it."),
        ("Urgency driver", "How to use it."),
        ("Urgency driver", "How to use it."),
    ],

    # ── S11 The Referral Engine ───────────────────────────────────────────────
    "referral_paragraph": (
        "Describe the specific moment in the client's business when a "
        "referral naturally occurs — what the customer just experienced, "
        "who they tell, and what makes the referral convert into a sale."   # ← FILL
    ),
    # (Referral Trigger, Action to Take)
    "referral_table": [
        ("Trigger: when does the referral moment occur?",
         "Action: what exactly does the client or their team do or say?"),  # ← FILL
        ("Trigger", "Action."),
        ("Trigger", "Action."),
        ("Trigger", "Action."),
    ],

    # ── S12 30-60-90 Revenue Acceleration Path ────────────────────────────────
    # (Milestone, Action, Revenue Impact, Owner)
    "acceleration_path": [
        ("Day 1–30",
         "Action: what is built or deployed in the first 30 days.",
         "Revenue impact: what this action unlocks.",
         "Owner"),                                                 # ← FILL
        ("Day 30–60", "Action.", "Impact.", "Owner"),
        ("Day 60–90", "Action.", "Impact.", "Owner"),
        ("Month 4–6", "Action.", "Impact.", "Owner"),
        ("Month 6–12","Action.", "Impact.", "Owner"),
    ],
}

# ══════════════════════════════════════════════════════════════════════════════
# BUILDER
# ══════════════════════════════════════════════════════════════════════════════

def build(client, logo_path, output_dir):
    C = CONTENT
    client_name = client["name"]
    doc_title   = "Sales Strategy Playbook"
    out_path    = os.path.join(output_dir,
                               f"05_Sales_Strategy_{client['slug']}.pdf")

    story = []
    story += build_cover("SALES STRATEGY PLAYBOOK",
                         "SALES STRATEGY", "PLAYBOOK",
                         f"{client_name} — Selling on Value, Offers That Cannot Be Compared",
                         client["date"])
    story += build_toc([
        ("01","The Commodity Problem and the Reframe"),
        ("02","What You Actually Sell"),
        ("03","The Value Equation"),
        ("04","Define the Niche Precisely"),
        ("05","Verify Market Conditions — The Four Indicators"),
        ("06","Name the Offer"),
        ("07","Build the Offer Stack"),
        ("08","Pricing and Framing Strategy"),
        ("09","Guarantees That Build Trust"),
        ("10","Real Urgency That Already Exists"),
        ("11","The Referral Engine"),
        ("12","The 30-60-90 Revenue Acceleration Path"),
    ])

    # S01
    story.append(PageBreak())
    story += section_label(1, "The Commodity Problem and the Reframe")
    for para in C["commodity_paragraphs"]:
        story.append(Paragraph(para, sBody))
        story.append(sp(4))

    # S02
    story.append(PageBreak())
    story += section_label(2, "What You Actually Sell")
    story.append(Paragraph(
        f"{client_name} does not sell products or services in isolation. "
        "It sells the outcome, the certainty, and the relief those capabilities "
        "create for the buyer.", sBody))
    story.append(sp(8))
    story.append(two_col_table(
        ["WHAT YOU DELIVER", "THE REAL OUTCOME FOR THE BUYER"],
        C["actual_sells"],
    ))

    # S03
    story.append(PageBreak())
    story += section_label(3, "The Value Equation")
    story.append(Paragraph(
        "Value is determined by four factors. The best operators in any "
        "industry understand that the real competitive advantage is not "
        "making bigger promises — it is reducing the friction, time, and "
        "effort the buyer experiences.", sBody))
    story.append(sp(8))
    story.append(three_col_table(
        ["VALUE DRIVER", "GOAL", "CLIENT APPLICATION"],
        C["value_equation"],
    ))
    story.append(sp(8))
    story.append(Paragraph(C["value_note"], sBody))

    # S04
    story.append(PageBreak())
    story += section_label(4, "Define the Niche Precisely")
    story.append(Paragraph(
        "The more precisely the ideal account is described, the faster "
        "those accounts self-identify and reach out — and the less the "
        "sales conversation has to do to establish fit.", sBody))
    story.append(sp(8))
    story.append(Paragraph("RECOMMENDED PRIMARY AVATAR", sH3))
    story.append(Paragraph(C["avatar_description"], sBody))
    story.append(sp(8))
    story.append(two_col_table(
        ["AVATAR CHARACTERISTIC", "WHY IT MATTERS FOR SALES"],
        C["avatar_table"],
    ))

    # S05
    story.append(PageBreak())
    story += section_label(5, "Verify Market Conditions — The Four Indicators")
    story.append(sp(6))
    story.append(two_col_table(
        ["INDICATOR", "CLIENT REALITY CHECK"],
        C["market_indicators"],
        col_widths=[CONTENT_W*0.22, CONTENT_W*0.78]
    ))

    # S06
    story.append(PageBreak())
    story += section_label(6, "Name the Offer")
    story.append(Paragraph(
        "A named offer is more memorable, more referable, and more "
        "differentiated than a generic service description. The formula: "
        "magnetic reason + specific buyer + outcome + timeframe + container word.", sBody))
    story.append(sp(8))
    story.append(two_col_table(["OFFER TYPE", "NAMED VERSION"], C["named_offers"]))
    story.append(sp(8))
    story.append(Paragraph(C["naming_note"], sBody))

    # S07
    story.append(PageBreak())
    story += section_label(7, "Build the Offer Stack")
    story.append(Paragraph(
        "A bundle of components addressing specific buyer objections is more "
        "compelling than a single product listing. Each addition should remove "
        "a real hesitation.", sBody))
    story.append(sp(8))
    story.append(three_col_table(
        ["OFFER COMPONENT", "OBSTACLE IT ADDRESSES", "PERCEIVED VALUE"],
        C["offer_stack"],
    ))

    # S08
    story.append(PageBreak())
    story += section_label(8, "Pricing and Framing Strategy")
    story.append(Paragraph(
        "The pricing conversation is won or lost before the price is stated "
        "— in how the service is described.", sBody))
    story.append(sp(8))
    story.append(two_col_table(
        ["FRAMING TYPE", "EXAMPLE"],
        [
            ("Weak — price-first",  C["pricing_weak"]),
            ("Strong — value-first", C["pricing_strong"]),
        ],
    ))
    story.append(sp(8))
    story.append(Paragraph(C["pricing_note"], sBody))

    # S09
    story.append(PageBreak())
    story += section_label(9, "Guarantees That Build Trust Without Creating Risk")
    story.append(sp(4))
    for g_title, g_body in C["guarantees"]:
        story.append(Paragraph(g_title, sH3))
        story.append(Paragraph(g_body, sBody))
        story.append(sp(6))

    # S10
    story.append(PageBreak())
    story += section_label(10, "Real Urgency That Already Exists")
    story.append(Paragraph(
        "Artificial urgency destroys credibility with sophisticated buyers. "
        "Real constraints create genuine urgency — these are the authentic "
        "urgency drivers in this business.", sBody))
    story.append(sp(8))
    story.append(two_col_table(
        ["URGENCY DRIVER", "HOW TO USE IT"],
        C["urgency_drivers"],
    ))

    # S11
    story.append(PageBreak())
    story += section_label(11, "The Referral Engine")
    story.append(Paragraph(C["referral_paragraph"], sBody))
    story.append(sp(8))
    story.append(two_col_table(
        ["REFERRAL TRIGGER", "ACTION TO TAKE"],
        C["referral_table"],
    ))

    # S12
    story.append(PageBreak())
    story += section_label(12, "The 30-60-90 Revenue Acceleration Path")
    story.append(sp(6))
    story.append(four_col_table(
        ["MILESTONE", "ACTION", "REVENUE IMPACT", "OWNER"],
        C["acceleration_path"],
        col_widths=[CONTENT_W*0.12, CONTENT_W*0.32, CONTENT_W*0.36, CONTENT_W*0.20]
    ))
    story += closing(doc_title)

    build_pdf(out_path, story, doc_title, client_name, logo_path)
    return out_path
