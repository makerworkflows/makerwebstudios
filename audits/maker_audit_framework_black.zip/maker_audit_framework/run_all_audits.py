"""
run_all_audits.py
─────────────────────────────────────────────────────────────────────────────
Maker Web Studios — Audit PDF Generator
─────────────────────────────────────────────────────────────────────────────

USAGE:
  1. Fill the CLIENT block below with the new client's details.
  2. Open each template file in templates/ and fill its CONTENT dict.
  3. Run:  python run_all_audits.py
  4. Collect the 5 PDFs from the output/ folder.

That's it. Design, colors, fonts, layout — all handled automatically.
─────────────────────────────────────────────────────────────────────────────
"""

import os
import sys
import re

# ══════════════════════════════════════════════════════════════════════════════
# CLIENT CONFIGURATION — edit this block for every new client
# ══════════════════════════════════════════════════════════════════════════════

CLIENT = {
    # Display name — used in headers, cover pages, and PDF metadata
    "name":    "Rio Grande Steel, Ltd.",                          # ← FILL

    # Website URL (no https://) — used in audit copy
    "url":     "riograndesteel.com",                              # ← FILL

    # One-line industry / specialty description
    "industry":"Fabricated Reinforcing Steel & Construction Supply", # ← FILL

    # City, State (or City, Country for international)
    "location":"Rio Grande Valley, South Texas",                  # ← FILL

    # Month Year — appears on cover pages and footers
    "date":    "March 2026",                                      # ← FILL
}

# ── Paths (only change if you move files) ────────────────────────────────────
LOGO_PATH  = os.path.join(os.path.dirname(__file__), "assets", "Maker_Logo_Official.png")
OUTPUT_DIR = os.path.join(os.path.dirname(__file__), "output")

# ══════════════════════════════════════════════════════════════════════════════
# DO NOT EDIT BELOW THIS LINE
# ══════════════════════════════════════════════════════════════════════════════

def _make_slug(name):
    """Convert client name to a safe filename slug."""
    slug = re.sub(r"[^\w\s-]", "", name)
    slug = re.sub(r"[\s]+", "_", slug.strip())
    return slug

def _check_logo():
    if not os.path.exists(LOGO_PATH):
        print(f"\n  ⚠  Logo not found at: {LOGO_PATH}")
        print("     PDFs will render without the logo.")
        print("     Drop Maker_Logo_Official.png into the assets/ folder to fix.\n")
        return None
    return LOGO_PATH

def _check_deps():
    try:
        import reportlab
    except ImportError:
        print("\n  ✗  reportlab is not installed.")
        print("     Run:  pip install reportlab\n")
        sys.exit(1)

def main():
    _check_deps()
    logo = _check_logo()

    client = {**CLIENT, "slug": _make_slug(CLIENT["name"])}
    os.makedirs(OUTPUT_DIR, exist_ok=True)

    print(f"\n{'='*60}")
    print(f"  Maker Web Studios — Audit PDF Generator")
    print(f"  Client : {client['name']}")
    print(f"  URL    : {client['url']}")
    print(f"  Output : {OUTPUT_DIR}/")
    print(f"{'='*60}\n")

    # Import templates dynamically so each can be developed independently
    template_dir = os.path.join(os.path.dirname(__file__), "templates")
    sys.path.insert(0, template_dir)
    sys.path.insert(0, os.path.dirname(__file__))

    templates = [
        ("audit_01_digital_presence", "Digital Presence Audit"),
        ("audit_02_blind_spot",       "Blind Spot Audit"),
        ("audit_03_market_forecast",  "Market Analysis & 5-Year Forecast"),
        ("audit_04_growth_strategy",  "Growth Strategy Playbook"),
        ("audit_05_sales_strategy",   "Sales Strategy Playbook"),
    ]

    results = []
    errors  = []

    for module_name, label in templates:
        print(f"  Building: {label}...")
        try:
            # Import fresh each time (supports re-runs in the same session)
            if module_name in sys.modules:
                del sys.modules[module_name]
            mod = __import__(module_name)
            out = mod.build(client, logo, OUTPUT_DIR)
            results.append(out)
        except Exception as e:
            import traceback
            errors.append((label, str(e)))
            print(f"  ✗  FAILED: {label}")
            traceback.print_exc()

    print(f"\n{'='*60}")
    if results:
        print(f"  ✓  {len(results)} PDF(s) written to: {OUTPUT_DIR}/")
        for r in results:
            print(f"       {os.path.basename(r)}")
    if errors:
        print(f"\n  ✗  {len(errors)} error(s):")
        for label, err in errors:
            print(f"       {label}: {err}")
    print(f"{'='*60}\n")

if __name__ == "__main__":
    main()
