# Maker Web Studios — Audit PDF Framework

A reusable system for generating all 5 client audit PDFs with consistent
branding, layout, and design — every time, for any client.

---

## Folder Structure

```
maker_audit_framework/
├── README.md               ← this file
├── run_all_audits.py       ← ONE command to build all 5 PDFs for a client
├── lib/
│   └── pdf_styles.py       ← ALL styles, colors, helpers (never edit per-client)
├── templates/
│   ├── audit_01_digital_presence.py
│   ├── audit_02_blind_spot.py
│   ├── audit_03_market_forecast.py
│   ├── audit_04_growth_strategy.py
│   └── audit_05_sales_strategy.py
├── assets/
│   └── Maker_Logo_Official.png   ← drop logo file here
└── output/
    └── (PDFs are written here)
```

---

## How to Use (Quick Start)

### 1. Install dependency (one time)
```bash
pip install reportlab
```

### 2. Add your logo
Drop `Maker_Logo_Official.png` into the `assets/` folder.

### 3. Fill in client data
Open `run_all_audits.py` and update the `CLIENT` config block at the top:

```python
CLIENT = {
    "name":        "Rio Grande Steel, Ltd.",
    "url":         "riograndesteel.com",
    "industry":    "Fabricated Reinforcing Steel & Construction Supply",
    "location":    "Rio Grande Valley, South Texas",
    "date":        "March 2026",
    "logo":        "assets/Maker_Logo_Official.png",
    "output_dir":  "output/",
}
```

Then open each `templates/audit_0X_*.py` file and fill in the
`CONTENT` dictionary at the top of that file with the client-specific
findings, scores, and narrative. Each field has clear instructions.

### 4. Run
```bash
python run_all_audits.py
```

Five branded PDFs appear in `output/`.

---

## Design Rules (Do Not Edit lib/pdf_styles.py)

The library controls all colors, fonts, spacing, and layout. If you want
to change the brand color or logo size, do it once in `pdf_styles.py` and
every template inherits it automatically.

| Element              | Value         |
|----------------------|---------------|
| Brand navy           | `#0e172a`     |
| Background gray      | `#F2F2F2`     |
| Border gray          | `#CCCCCC`     |
| Body font            | Helvetica 9pt |
| Heading font         | Helvetica-Bold 14pt |
| Page size            | US Letter     |
| Margins              | 0.75 inch     |

---

## For Claude Code / AI Usage

When starting a new client audit, paste this prompt into Claude Code:

> "New client: [CLIENT NAME]. URL: [URL]. Industry: [INDUSTRY].
> Location: [CITY, STATE]. Research the company and their website
> thoroughly, then populate all five CONTENT dictionaries in the
> maker_audit_framework/templates/ files and run run_all_audits.py
> to produce the five audit PDFs."

Claude Code will research the client, fill all five templates,
run the script, and produce the PDFs in output/.
